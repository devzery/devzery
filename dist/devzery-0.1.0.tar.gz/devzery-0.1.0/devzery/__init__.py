from importlib import import_module
import warnings
from .requests.patcher import DevzeryRequestsMiddleware  # Import the patch_requests function
from .requests import interceptor

__version__ = "0.1.0"

def get_django_middleware():
    try:
        return import_module('.django.middleware', 'devzery').RequestResponseLoggingMiddleware
    except ImportError as e:
        warnings.warn(
            "Django middleware is not available. "
            "Install Django first: pip install django"
        )
        raise

def get_flask_middleware():
    try:
        return import_module('.flask.middleware', 'devzery').FlaskRequestResponseLoggingMiddleware
    except ImportError as e:
        warnings.warn(
            "Flask middleware is not available. "
            "Install Flask first: pip install flask"
        )
        raise

# from importlib import import_module
# import warnings
# from .requests.patcher import DevzeryRequestsMiddleware
# from .requests import interceptor
#
# __version__ = "0.1.0"
#
# # Global variables to store middleware instances
# django_middleware = None
# flask_middleware = None
# requests_middleware = None
#
# def initialize(api_endpoint=None, api_key=None, source_name=None):
#     global django_middleware, flask_middleware, requests_middleware
#
#     # Initialize Django middleware
#     try:
#         django_middleware = import_module('.django.middleware', 'devzery').RequestResponseLoggingMiddleware(api_endpoint, api_key, source_name)
#     except ImportError as e:
#         warnings.warn(
#             "Django middleware is not available. "
#             "Install Django first: pip install django"
#         )
#
#     # Initialize Flask middleware
#     try:
#         flask_middleware = import_module('.flask.middleware', 'devzery').FlaskRequestResponseLoggingMiddleware(api_endpoint, api_key, source_name)
#     except ImportError as e:
#         warnings.warn(
#             "Flask middleware is not available. "
#             "Install Flask first: pip install flask"
#         )
#
#     # Initialize Requests middleware
#     requests_middleware = DevzeryRequestsMiddleware(api_endpoint, api_key, source_name)
#     requests_middleware.intercept_requests()
#
# def get_django_middleware():
#     if django_middleware is None:
#         raise RuntimeError("Django middleware is not initialized. Call initialize() first.")
#     return django_middleware
#
# def get_flask_middleware():
#     if flask_middleware is None:
#         raise RuntimeError("Flask middleware is not initialized. Call initialize() first.")
#     return flask_middleware
#
